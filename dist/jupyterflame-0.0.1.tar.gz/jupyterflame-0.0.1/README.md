# jupyterflame
Bringing flamegraphs into jupyter notebooks for performance diagnosis
